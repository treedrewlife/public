This is a CI build of WinHTTrack, not an installer.

Everything it needs is in this folder, including the Microsoft Visual C++
runtime and the UCRT, so there is no redistributable to install first.
Windows 7 SP1 is the exception: the runtime also needs KB2533623, which
only Windows Update can supply.

httrack.exe is the command-line version, against the same libhttrack.dll.

WinHTTrack.ini makes this copy portable: settings and mirrors stay in this
folder, nothing is written to the registry, and .whtt is not associated.
Delete it to get the usual per-user settings instead.
